package com.fooddelivery;
import java.util.*;

public class Main {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        List<Restaurant> restaurants = new ArrayList<>();
        List<Customer> customers = new ArrayList<>();
        List<Order> orders = new ArrayList<>();
        List<DeliveryPerson> deliveryPersons = new ArrayList<>();
        int orderCounter = 1;

        while (true) {
            System.out.println("=================================");
            System.out.println("|       FOOD DELIVERY MENU      |");
            System.out.println("=================================");
            System.out.println("| 1. Admin Menu                 |");
            System.out.println("| 2. Customer Menu              |");
            System.out.println("| 3. Exit                       |");
            System.out.println("=================================");
            System.out.print("Choose an option: ");
            int mainChoice = scanner.nextInt();
            scanner.nextLine();

            if (mainChoice == 1) { // Admin Menu
                while (true) {
                    System.out.println("\n------------------------------");
                    System.out.println("         ADMIN MENU           ");
                    System.out.println("------------------------------");
                    System.out.println("1. Add Restaurant");
                    System.out.println("2. Add Food Item to Restaurant");
                    System.out.println("3. Remove Food Item from Restaurant");
                    System.out.println("4. View Restaurants and Menus");
                    System.out.println("5. View Orders");
                    System.out.println("6. Add Delivery Person");
                    System.out.println("7. Assign Delivery Person to Order");
                    System.out.println("8. Exit");
                    System.out.println("------------------------------");
                    System.out.print("Choose an option: ");
                    int adminChoice = scanner.nextInt();
                    scanner.nextLine();

                    if (adminChoice == 1) {
                        System.out.print("Enter Restaurant ID: ");
                        int rid = scanner.nextInt();
                        scanner.nextLine();
                        System.out.print("Enter Restaurant Name: ");
                        String rname = scanner.nextLine();
                        restaurants.add(new Restaurant(rid, rname));
                        System.out.println("Restaurant added successfully!");
                    } else if (adminChoice == 2) {
                        System.out.print("Enter Restaurant ID: ");
                        int rid = scanner.nextInt();
                        scanner.nextLine();
                        System.out.print("Enter Food Item ID: ");
                        int fid = scanner.nextInt();
                        scanner.nextLine();
                        System.out.print("Enter Food Item Name: ");
                        String fname = scanner.nextLine();
                        System.out.print("Enter Food Item Price: ");
                        double fprice = scanner.nextDouble();
                        scanner.nextLine();
                        boolean found = false;
                        for (Restaurant r : restaurants) {
                            if (r.getId() == rid) {
                                r.addFoodItem(new FoodItem(fid, fname, fprice));
                                found = true;
                                break;
                            }
                        }
                        if (!found) {
                            System.out.println("Restaurant not found!");
                        }
                    } else if (adminChoice == 3) {
                        System.out.print("Enter Restaurant ID: ");
                        int rid = scanner.nextInt();
                        scanner.nextLine();
                        System.out.print("Enter Food Item ID: ");
                        int fid = scanner.nextInt();
                        scanner.nextLine();
                        boolean found = false;
                        for (Restaurant r : restaurants) {
                            if (r.getId() == rid) {
                                r.removeFoodItem(fid);
                                found = true;
                                break;
                            }
                        }
                        if (!found) {
                            System.out.println("Restaurant not found!");
                        }
                    }  else if (adminChoice == 4) {
                        System.out.println("\n----- Restaurants and Menus -----");
                        System.out.println("---------------------------------------------------------------");
                        System.out.printf("| %-14s | %-20s | %-25s |\n", "Restaurant ID", "Restaurant Name", "Food Items");
                        System.out.println("---------------------------------------------------------------");
                        for (Restaurant r : restaurants) {
                            StringBuilder itemsStr = new StringBuilder();
                            for (FoodItem fi : r.getMenu()) {
                                itemsStr.append(String.format("ID:%d, %s, Rs.%.1f; ", fi.getId(), fi.getName(), fi.getPrice()));
                            }
                            if (itemsStr.length() == 0) {
                                itemsStr.append("None");
                            }
                            System.out.printf("| %-14d | %-20s | %-25s |\n", r.getId(), r.getName(), itemsStr.toString());
                            System.out.println("---------------------------------------------------------------");
                        }
                    } else if (adminChoice == 5) {
                        System.out.println("\n----------- Orders -----------");
                        if (orders.isEmpty()) {
                            System.out.println("No orders available.");
                        } else {
                            for (Order o : orders) {
                                System.out.println(o);
                            }
                        }
                        System.out.println("------------------------------");
                    } else if (adminChoice == 6) {
                        System.out.print("Enter Delivery Person ID: ");
                        int dpId = scanner.nextInt();
                        scanner.nextLine();
                        System.out.print("Enter Delivery Person Name: ");
                        String dpName = scanner.nextLine();
                        System.out.print("Enter Contact No.: ");
                        long dpContact = scanner.nextLong();
                        scanner.nextLine();
                        deliveryPersons.add(new DeliveryPerson(dpId, dpName, dpContact));
                        System.out.println("Delivery person added successfully!");
                    } else if (adminChoice == 7) {
                        System.out.print("Enter Order ID: ");
                        int oid = scanner.nextInt();
                        System.out.print("Enter Delivery Person ID: ");
                        int dpId = scanner.nextInt();
                        scanner.nextLine();
                        boolean orderFound = false;
                        for (Order o : orders) {
                            if (o.getOrderId() == oid) {
                                orderFound = true;
                                boolean dpFound = false;
                                for (DeliveryPerson dp : deliveryPersons) {
                                    if (dp.getDeliveryPersonId() == dpId) {
                                        o.assignDeliveryPerson(dp);
                                        dpFound = true;
                                        break;
                                    }
                                }
                                if (!dpFound) {
                                    System.out.println("Delivery Person not found!");
                                }
                                break;
                            }
                        }
                        if (!orderFound) {
                            System.out.println("Order not found!");
                        }
                    } else if (adminChoice == 8) {
                        System.out.println("Exiting Admin Module");
                        break;
                    } else {
                        System.out.println("Invalid option! Please try again.");
                    }
                }
            } else if (mainChoice == 2) { // Customer Menu
                while (true) {
                    System.out.println("\n------------------------------");
                    System.out.println("         CUSTOMER MENU        ");
                    System.out.println("------------------------------");
                    System.out.println("1. Add Customer");
                    System.out.println("2. View Food Items");
                    System.out.println("3. Add Food to Cart");
                    System.out.println("4. View Cart");
                    System.out.println("5. Place Order");
                    System.out.println("6. View Orders");
                    System.out.println("7. Exit");
                    System.out.println("------------------------------");
                    System.out.print("Choose an option: ");
                    int custChoice = scanner.nextInt();
                    scanner.nextLine();

                    if (custChoice == 1) {
                        System.out.print("Enter User ID: ");
                        int uid = scanner.nextInt();
                        scanner.nextLine();
                        System.out.print("Enter Username: ");
                        String uname = scanner.nextLine();
                        System.out.print("Enter Contact No.: ");
                        long ucontact = scanner.nextLong();
                        scanner.nextLine();
                        customers.add(new Customer(uid, uname, ucontact));
                        System.out.println("Customer created successfully!");
                    } else if (custChoice == 2) {
                        System.out.println("\n----- Restaurants and Menus -----");
                        for (Restaurant r : restaurants) {
                            System.out.println("Restaurant ID: " + r.getId() + ", Name: " + r.getName());
                            if (r.getMenu().isEmpty()) {
                                System.out.println("   No food items available.");
                            } else {
                                for (FoodItem fi : r.getMenu()) {
                                    System.out.println("   - Food Item ID: " + fi.getId() + ", Name: " + fi.getName() + ", Price: Rs." + fi.getPrice());
                                }
                            }
                            System.out.println("---------------------------------");
                        }
                    } else if (custChoice == 3) {
                        System.out.print("Enter Customer ID: ");
                        int uid = scanner.nextInt();
                        System.out.print("Enter Restaurant ID: ");
                        int rid = scanner.nextInt();
                        System.out.print("Enter Food Item ID: ");
                        int fid = scanner.nextInt();
                        System.out.print("Enter Quantity: ");
                        int qty = scanner.nextInt();
                        scanner.nextLine();
                        boolean custFound = false;
                        for (Customer c : customers) {
                            if (c.getUserId() == uid) {
                                custFound = true;
                                boolean restaurantFound = false;
                                for (Restaurant r : restaurants) {
                                    if (r.getId() == rid) {
                                        restaurantFound = true;
                                        boolean foodFound = false;
                                        for (FoodItem fi : r.getMenu()) {
                                            if (fi.getId() == fid) {
                                                c.getCart().addItem(fi, qty);
                                                foodFound = true;
                                                break;
                                            }
                                        }
                                        if (!foodFound) {
                                            System.out.println("Food item not found!");
                                        }
                                        break;
                                    }
                                }
                                if (!restaurantFound) {
                                    System.out.println("Restaurant not found!");
                                }
                                break;
                            }
                        }
                        if (!custFound) {
                            System.out.println("Customer not found!");
                        }
                    } else if (custChoice == 4) {
                        System.out.print("Enter Customer ID: ");
                        int uid = scanner.nextInt();
                        scanner.nextLine();
                        boolean custFound = false;
                        for (Customer c : customers) {
                            if (c.getUserId() == uid) {
                                custFound = true;
                                c.getCart().viewCart();
                                break;
                            }
                        }
                        if (!custFound) {
                            System.out.println("Customer not found!");
                        }
                    } else if (custChoice == 5) {
                        System.out.print("Enter Customer ID: ");
                        int uid = scanner.nextInt();
                        scanner.nextLine();
                        boolean custFound = false;
                        for (Customer c : customers) {
                            if (c.getUserId() == uid) {
                                custFound = true;
                                Order newOrder = new Order(orderCounter++, c, c.getCart().getItems());
                                orders.add(newOrder);
                                System.out.println("Order placed successfully! Your order ID is: " + newOrder.getOrderId());
                                c.getCart().getItems().clear();
                                break;
                            }
                        }
                        if (!custFound) {
                            System.out.println("Customer not found!");
                        }
                    } else if (custChoice == 6) {
                        System.out.print("Enter Customer ID: ");
                        int uid = scanner.nextInt();
                        scanner.nextLine();
                        boolean orderFound = false;
                        System.out.println("\n----------- Orders -----------");
                        for (Order o : orders) {
                            if (o.getCustomerId() == uid) {
                                System.out.println(o);
                                orderFound = true;
                            }
                        }
                        if (!orderFound) {
                            System.out.println("No orders found for this customer!");
                        }
                        System.out.println("------------------------------");
                    } else if (custChoice == 7) {
                        System.out.println("Exiting Customer Module");
                        break;
                    } else {
                        System.out.println("Invalid option! Please try again.");
                    }
                }
            } else if (mainChoice == 3) {
                System.out.println("Exiting...");
                break;
            } else {
                System.out.println("Invalid option. Please try again.");
            }
        }
        scanner.close();
    }
}
