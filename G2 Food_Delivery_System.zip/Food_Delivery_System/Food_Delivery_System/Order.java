package com.fooddelivery;
import java.util.*;

public class Order {
    private int orderId;
    private Customer customer;
    private Map<FoodItem, Integer> items;
    private String status = "Pending";
    private DeliveryPerson deliveryPerson;

    public Order(int orderId, Customer customer, Map<FoodItem, Integer> items) {
        this.orderId = orderId;
        this.customer = customer;
        this.items = new HashMap<>(items);
    }

    public int getOrderId() { return orderId; }
    public int getCustomerId() { return customer.getUserId(); }

    public void assignDeliveryPerson(DeliveryPerson deliveryPerson) {
        this.deliveryPerson = deliveryPerson;
    }

    @Override
    public String toString() {
        StringBuilder sb = new StringBuilder();
        sb.append("=================================\n");
        sb.append("Order ID: ").append(orderId).append("\n");
        sb.append("Customer: ").append(customer.getUsername()).append("\n");
        sb.append("Status: ").append(status).append("\n");
        sb.append("Delivery Person: ").append(deliveryPerson != null ? deliveryPerson.getName() : "Not Assigned").append("\n");
        sb.append("Items:\n");
        for (Map.Entry<FoodItem, Integer> entry : items.entrySet()) {
            FoodItem fi = entry.getKey();
            int qty = entry.getValue();
            sb.append("   - Food Item: ").append(fi.getName())
              .append(" (ID: ").append(fi.getId()).append(") ")
              .append(" x ").append(qty)
              .append(" = Rs.").append(fi.getPrice() * qty).append("\n");
        }
        sb.append("=================================\n");
        return sb.toString();
    }
}
