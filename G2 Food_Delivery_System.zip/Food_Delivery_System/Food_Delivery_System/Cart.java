package com.fooddelivery;
import java.util.*;

public class Cart {
    private Map<FoodItem, Integer> items = new HashMap<>();

    public void addItem(FoodItem foodItem, int quantity) {
        items.put(foodItem, items.getOrDefault(foodItem, 0) + quantity);
        System.out.println("✅ Food item added to cart!");
    }

    public void removeItem(FoodItem foodItem) {
        items.remove(foodItem);
        System.out.println("🗑️ Food item removed from cart.");
    }

    public Map<FoodItem, Integer> getItems() { return items; }

    public void viewCart() {
        System.out.println("--------- CART ---------");
        double total = 0;
        for (Map.Entry<FoodItem, Integer> entry: items.entrySet()) {
            FoodItem fi = entry.getKey();
            int qty = entry.getValue();
            double cost = fi.getPrice() * qty;
            total += cost;
            System.out.println("Food Item: " + fi.getName() + " (ID: " + fi.getId() + ") | Quantity: " + qty + " | Cost: Rs." + cost);
        }
        System.out.println("Total Cost: Rs." + total);
        System.out.println("------------------------");
    }
}
