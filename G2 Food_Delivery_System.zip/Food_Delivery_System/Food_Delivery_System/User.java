package com.fooddelivery;

public abstract class User {
    protected int userId;
    protected String username;
    protected long contactNo;

    public User(int userId, String username, long contactNo) {
        this.userId = userId;
        this.username = username;
        this.contactNo = contactNo;
    }

    public int getUserId() { return userId; }
    public String getUsername() { return username; }
    public long getContactNo() { return contactNo; }

    @Override
    public String toString() {
        return "User{id=" + userId + ", username='" + username + "', contactNo=" + contactNo + "}";
    }
}
